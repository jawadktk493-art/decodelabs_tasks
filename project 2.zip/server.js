// server.js
// -----------------------------------------------------------------------
// Project 3: Database Integration — DecodeLabs Task Manager
//
// Pillar 3: The Action — CRUD mapped to RESTful HTTP verbs exactly as
// specced in the training kit:
//   CREATE = POST    = SQL INSERT
//   READ   = GET     = SQL SELECT
//   UPDATE = PUT/PATCH = SQL UPDATE
//   DELETE = DELETE  = SQL DELETE
//
// Pillar 4: The Shield — every single query below uses parameter
// placeholders (`?`) and bound values, never string concatenation.
// User input is always treated as data, never as executable SQL.
//
// Built on Node's built-in `http` module only — no Express, no external
// packages — so it runs anywhere `node server.js` runs.
// -----------------------------------------------------------------------

const http = require('http');
const fs = require('fs');
const path = require('path');
const db = require('./db');

const PORT = process.env.PORT || 3000;
const PUBLIC_DIR = path.join(__dirname, 'public');

// -----------------------------------------------------------------------
// Small helpers
// -----------------------------------------------------------------------
function sendJSON(res, status, payload) {
  const body = JSON.stringify(payload, null, 2);
  res.writeHead(status, {
    'Content-Type': 'application/json',
    'Content-Length': Buffer.byteLength(body),
  });
  res.end(body);
}

function notFound(res, resource = 'Resource') {
  sendJSON(res, 404, { error: `${resource} not found` });
}

function badRequest(res, message) {
  sendJSON(res, 400, { error: message });
}

// Maps known SQLite constraint failures to clean 4xx responses instead of
// leaking a raw 500 stack trace — this is what "Ensure proper data
// handling" means in practice.
function handleDbError(res, err) {
  const msg = err.message || String(err);
  if (msg.includes('UNIQUE constraint failed')) {
    return sendJSON(res, 409, { error: 'A record with that unique value already exists.', detail: msg });
  }
  if (msg.includes('CHECK constraint failed')) {
    return sendJSON(res, 400, { error: 'Value violates an allowed range/set.', detail: msg });
  }
  if (msg.includes('NOT NULL constraint failed')) {
    return sendJSON(res, 400, { error: 'A required field is missing.', detail: msg });
  }
  if (msg.includes('FOREIGN KEY constraint failed')) {
    return sendJSON(res, 400, { error: 'Referenced record does not exist.', detail: msg });
  }
  console.error(err);
  return sendJSON(res, 500, { error: 'Internal server error' });
}

function readBody(req) {
  return new Promise((resolve, reject) => {
    let data = '';
    req.on('data', (chunk) => {
      data += chunk;
      if (data.length > 1e6) req.destroy(); // basic guard against huge payloads
    });
    req.on('end', () => {
      if (!data) return resolve({});
      try {
        resolve(JSON.parse(data));
      } catch {
        reject(new Error('Invalid JSON body'));
      }
    });
    req.on('error', reject);
  });
}

const VALID_STATUSES = ['pending', 'in_progress', 'done'];

// =========================================================================
// USERS  — /api/users
// =========================================================================
const Users = {
  list(res) {
    const rows = db.prepare('SELECT id, name, email, created_at FROM users ORDER BY id').all();
    sendJSON(res, 200, rows);
  },

  get(res, id) {
    const row = db.prepare('SELECT id, name, email, created_at FROM users WHERE id = ?').get(id);
    if (!row) return notFound(res, 'User');
    sendJSON(res, 200, row);
  },

  create(res, body) {
    const { name, email } = body;
    if (!name || !email) return badRequest(res, 'name and email are required.');
    try {
      const stmt = db.prepare('INSERT INTO users (name, email) VALUES (?, ?)');
      const info = stmt.run(name, email);
      const row = db.prepare('SELECT id, name, email, created_at FROM users WHERE id = ?')
        .get(info.lastInsertRowid);
      sendJSON(res, 201, row);
    } catch (err) {
      handleDbError(res, err);
    }
  },

  update(res, id, body) {
    const existing = db.prepare('SELECT id FROM users WHERE id = ?').get(id);
    if (!existing) return notFound(res, 'User');
    const { name, email } = body;
    if (!name || !email) return badRequest(res, 'name and email are required.');
    try {
      db.prepare('UPDATE users SET name = ?, email = ? WHERE id = ?').run(name, email, id);
      const row = db.prepare('SELECT id, name, email, created_at FROM users WHERE id = ?').get(id);
      sendJSON(res, 200, row);
    } catch (err) {
      handleDbError(res, err);
    }
  },

  remove(res, id) {
    const existing = db.prepare('SELECT id FROM users WHERE id = ?').get(id);
    if (!existing) return notFound(res, 'User');
    // ON DELETE CASCADE takes care of the user's tasks automatically.
    db.prepare('DELETE FROM users WHERE id = ?').run(id);
    sendJSON(res, 200, { deleted: true, id });
  },
};

// =========================================================================
// CATEGORIES — /api/categories
// =========================================================================
const Categories = {
  list(res) {
    sendJSON(res, 200, db.prepare('SELECT * FROM categories ORDER BY id').all());
  },

  create(res, body) {
    const { name } = body;
    if (!name) return badRequest(res, 'name is required.');
    try {
      const info = db.prepare('INSERT INTO categories (name) VALUES (?)').run(name);
      sendJSON(res, 201, { id: info.lastInsertRowid, name });
    } catch (err) {
      handleDbError(res, err);
    }
  },

  remove(res, id) {
    const existing = db.prepare('SELECT id FROM categories WHERE id = ?').get(id);
    if (!existing) return notFound(res, 'Category');
    db.prepare('DELETE FROM categories WHERE id = ?').run(id);
    sendJSON(res, 200, { deleted: true, id });
  },
};

// =========================================================================
// TASKS — /api/tasks
// =========================================================================
const Tasks = {
  // Supports optional filtering: GET /api/tasks?user_id=1&status=pending
  list(res, query) {
    let sql = `
      SELECT t.*,
             u.name AS user_name,
             (SELECT json_group_array(c.name)
                FROM task_categories tc
                JOIN categories c ON c.id = tc.category_id
               WHERE tc.task_id = t.id) AS categories
        FROM tasks t
        JOIN users u ON u.id = t.user_id
       WHERE 1 = 1
    `;
    const params = [];
    if (query.user_id) {
      sql += ' AND t.user_id = ?';
      params.push(query.user_id);
    }
    if (query.status) {
      sql += ' AND t.status = ?';
      params.push(query.status);
    }
    sql += ' ORDER BY t.id';

    const rows = db.prepare(sql).all(...params).map((r) => ({
      ...r,
      categories: JSON.parse(r.categories || '[]'),
    }));
    sendJSON(res, 200, rows);
  },

  get(res, id) {
    const row = db.prepare(`
      SELECT t.*, u.name AS user_name
        FROM tasks t JOIN users u ON u.id = t.user_id
       WHERE t.id = ?
    `).get(id);
    if (!row) return notFound(res, 'Task');
    const categories = db.prepare(`
      SELECT c.id, c.name FROM categories c
      JOIN task_categories tc ON tc.category_id = c.id
      WHERE tc.task_id = ?
    `).all(id);
    sendJSON(res, 200, { ...row, categories });
  },

  create(res, body) {
    const { user_id, title, description = null, status = 'pending', due_date = null } = body;
    if (!user_id || !title) return badRequest(res, 'user_id and title are required.');
    if (!VALID_STATUSES.includes(status)) {
      return badRequest(res, `status must be one of: ${VALID_STATUSES.join(', ')}`);
    }
    try {
      const info = db.prepare(`
        INSERT INTO tasks (user_id, title, description, status, due_date)
        VALUES (?, ?, ?, ?, ?)
      `).run(user_id, title, description, status, due_date);
      const row = db.prepare('SELECT * FROM tasks WHERE id = ?').get(info.lastInsertRowid);
      sendJSON(res, 201, row);
    } catch (err) {
      handleDbError(res, err);
    }
  },

  // Full update (PUT) — replaces the editable fields wholesale.
  update(res, id, body) {
    const existing = db.prepare('SELECT id FROM tasks WHERE id = ?').get(id);
    if (!existing) return notFound(res, 'Task');
    const { title, description = null, status = 'pending', due_date = null } = body;
    if (!title) return badRequest(res, 'title is required.');
    if (!VALID_STATUSES.includes(status)) {
      return badRequest(res, `status must be one of: ${VALID_STATUSES.join(', ')}`);
    }
    try {
      db.prepare(`
        UPDATE tasks SET title = ?, description = ?, status = ?, due_date = ?
        WHERE id = ?
      `).run(title, description, status, due_date, id);
      sendJSON(res, 200, db.prepare('SELECT * FROM tasks WHERE id = ?').get(id));
    } catch (err) {
      handleDbError(res, err);
    }
  },

  // Partial update (PATCH) — e.g. just flipping status, as a Kanban board would.
  patchStatus(res, id, body) {
    const existing = db.prepare('SELECT id FROM tasks WHERE id = ?').get(id);
    if (!existing) return notFound(res, 'Task');
    const { status } = body;
    if (!VALID_STATUSES.includes(status)) {
      return badRequest(res, `status must be one of: ${VALID_STATUSES.join(', ')}`);
    }
    db.prepare('UPDATE tasks SET status = ? WHERE id = ?').run(status, id);
    sendJSON(res, 200, db.prepare('SELECT * FROM tasks WHERE id = ?').get(id));
  },

  remove(res, id) {
    const existing = db.prepare('SELECT id FROM tasks WHERE id = ?').get(id);
    if (!existing) return notFound(res, 'Task');
    db.prepare('DELETE FROM tasks WHERE id = ?').run(id);
    sendJSON(res, 200, { deleted: true, id });
  },

  linkCategory(res, taskId, body) {
    const task = db.prepare('SELECT id FROM tasks WHERE id = ?').get(taskId);
    if (!task) return notFound(res, 'Task');
    const { category_id } = body;
    if (!category_id) return badRequest(res, 'category_id is required.');
    try {
      db.prepare('INSERT INTO task_categories (task_id, category_id) VALUES (?, ?)')
        .run(taskId, category_id);
      sendJSON(res, 201, { task_id: Number(taskId), category_id });
    } catch (err) {
      handleDbError(res, err);
    }
  },

  unlinkCategory(res, taskId, categoryId) {
    const info = db.prepare(
      'DELETE FROM task_categories WHERE task_id = ? AND category_id = ?'
    ).run(taskId, categoryId);
    if (info.changes === 0) return notFound(res, 'Task/category link');
    sendJSON(res, 200, { deleted: true, task_id: Number(taskId), category_id: Number(categoryId) });
  },
};

// -----------------------------------------------------------------------
// Static file serving for the demo frontend in /public
// -----------------------------------------------------------------------
const MIME = {
  '.html': 'text/html', '.js': 'text/javascript', '.css': 'text/css',
  '.json': 'application/json', '.svg': 'image/svg+xml',
};

function serveStatic(req, res, pathname) {
  let filePath = pathname === '/' ? '/index.html' : pathname;
  filePath = path.join(PUBLIC_DIR, filePath);
  if (!filePath.startsWith(PUBLIC_DIR)) return notFound(res); // path traversal guard
  fs.readFile(filePath, (err, content) => {
    if (err) return notFound(res, 'Page');
    const ext = path.extname(filePath);
    res.writeHead(200, { 'Content-Type': MIME[ext] || 'application/octet-stream' });
    res.end(content);
  });
}

// -----------------------------------------------------------------------
// Router
// -----------------------------------------------------------------------
const server = http.createServer(async (req, res) => {
  const url = new URL(req.url, `http://${req.headers.host}`);
  const { pathname } = url;
  const query = Object.fromEntries(url.searchParams);
  const segments = pathname.split('/').filter(Boolean); // e.g. ['api','tasks','3','categories']
  const method = req.method;

  if (!pathname.startsWith('/api/')) {
    return serveStatic(req, res, pathname);
  }

  let body = {};
  if (['POST', 'PUT', 'PATCH'].includes(method)) {
    try {
      body = await readBody(req);
    } catch {
      return badRequest(res, 'Malformed JSON in request body.');
    }
  }

  try {
    // /api/users
    if (segments[0] === 'api' && segments[1] === 'users') {
      const id = segments[2];
      if (!id && method === 'GET') return Users.list(res);
      if (!id && method === 'POST') return Users.create(res, body);
      if (id && method === 'GET') return Users.get(res, id);
      if (id && method === 'PUT') return Users.update(res, id, body);
      if (id && method === 'DELETE') return Users.remove(res, id);
    }

    // /api/categories
    if (segments[0] === 'api' && segments[1] === 'categories') {
      const id = segments[2];
      if (!id && method === 'GET') return Categories.list(res);
      if (!id && method === 'POST') return Categories.create(res, body);
      if (id && method === 'DELETE') return Categories.remove(res, id);
    }

    // /api/tasks
    if (segments[0] === 'api' && segments[1] === 'tasks') {
      const id = segments[2];
      const sub = segments[3];   // 'categories'
      const subId = segments[4]; // category id

      if (!id && method === 'GET') return Tasks.list(res, query);
      if (!id && method === 'POST') return Tasks.create(res, body);
      if (id && !sub && method === 'GET') return Tasks.get(res, id);
      if (id && !sub && method === 'PUT') return Tasks.update(res, id, body);
      if (id && !sub && method === 'PATCH') return Tasks.patchStatus(res, id, body);
      if (id && !sub && method === 'DELETE') return Tasks.remove(res, id);
      if (id && sub === 'categories' && !subId && method === 'POST') {
        return Tasks.linkCategory(res, id, body);
      }
      if (id && sub === 'categories' && subId && method === 'DELETE') {
        return Tasks.unlinkCategory(res, id, subId);
      }
    }

    return notFound(res, 'Endpoint');
  } catch (err) {
    handleDbError(res, err);
  }
});

server.listen(PORT, () => {
  console.log(`DecodeLabs Task Manager API running at http://localhost:${PORT}`);
  console.log(`Frontend:  http://localhost:${PORT}/`);
  console.log(`API base:  http://localhost:${PORT}/api`);
});

# DecodeLabs — Project 3: Database Integration
### Task Manager API — a working implementation of the training kit's four pillars

This is a complete, runnable backend + demo frontend that satisfies every
requirement in the Project 3 brief: a designed schema, a real database
connection, full CRUD over a RESTful API, and enforced data integrity /
SQL-injection defense.

No external packages are required — it runs with just Node.js (v22.5+),
using the built-in `node:sqlite` driver and the built-in `http` module.

---

## 1. Run it

```bash
node server.js
```

Then open **http://localhost:3000** in a browser for the demo console, or
hit the API directly at `http://localhost:3000/api/...`.

The database file is created automatically at `data/app.db` on first run,
along with two seed users, three categories, and three tasks so there's
something to see immediately. Delete `data/app.db` to reset.

> Note: Node prints `ExperimentalWarning: SQLite is an experimental
> feature`. That's expected — `node:sqlite` is a newer built-in module —
> and does not affect functionality.

---

## 2. Schema (Pillar 1: The Blueprint)

```
users                    tasks                     categories
┌──────────────┐         ┌──────────────────┐      ┌──────────┐
│ id       PK  │────┐    │ id           PK  │  ┌───│ id   PK  │
│ name         │    └───<│ user_id      FK  │  │   │ name UQ  │
│ email    UQ  │         │ title            │  │   └──────────┘
│ created_at   │         │ description      │  │        ▲
└──────────────┘         │ status  CHECK    │  │        │
                          │ due_date         │  │   task_categories
                          │ created_at       │  │   ┌──────────────┐
                          └──────────────────┘  └──<│ task_id  FK  │
                                     ▲               │ category_id FK│
                                     └───────────────<│ (composite PK)│
                                                       └──────────────┘
```

- `users` → `tasks` is **one-to-many** (`user_id` foreign key, `ON DELETE CASCADE`).
- `tasks` ↔ `categories` is **many-to-many**, resolved through the
  `task_categories` junction table with a composite primary key.
- `tasks.status` is constrained with `CHECK (status IN ('pending','in_progress','done'))`
  — invalid values are rejected by the database itself, not just the app.
- `users.email` and `categories.name` are `UNIQUE`; core fields are `NOT NULL`.
- `PRAGMA foreign_keys = ON` is set explicitly (SQLite has it off by default).

## 3. Connection (Pillar 2: The Bridge)

`db.js` opens a single `DatabaseSync` connection to a native driver
(`node:sqlite`, same category as `pg` for Postgres) — chosen over an ORM
here so the raw SQL/parameterization is visible and auditable end to end.

## 4. CRUD → REST mapping (Pillar 3: The Action)

| Resource | Create | Read (all) | Read (one) | Update | Partial Update | Delete |
|---|---|---|---|---|---|---|
| Users | `POST /api/users` | `GET /api/users` | `GET /api/users/:id` | `PUT /api/users/:id` | — | `DELETE /api/users/:id` |
| Categories | `POST /api/categories` | `GET /api/categories` | — | — | — | `DELETE /api/categories/:id` |
| Tasks | `POST /api/tasks` | `GET /api/tasks` (`?user_id=`, `?status=`) | `GET /api/tasks/:id` | `PUT /api/tasks/:id` | `PATCH /api/tasks/:id` (status only) | `DELETE /api/tasks/:id` |
| Task↔Category link | `POST /api/tasks/:id/categories` | (embedded in task) | — | — | — | `DELETE /api/tasks/:id/categories/:categoryId` |

Every write returns the affected row (or `{deleted: true, id}`), and every
error returns a JSON body: `{ "error": "..." }`.

## 5. Integrity & security (Pillar 4: The Shield)

- **Every query uses parameter placeholders (`?`) with bound values** —
  never string concatenation — so user input can never be interpreted as
  SQL. Try it yourself: `GET /api/tasks?status=pending' OR '1'='1` returns
  an empty result set instead of dumping the table.
- Constraint violations (`UNIQUE`, `NOT NULL`, `CHECK`, `FOREIGN KEY`) are
  caught and translated into clean `400`/`409` JSON responses instead of
  leaking a raw database stack trace.
- Deleting a user cascades to their tasks (and a task's category links)
  automatically, at the database level — the app code doesn't have to
  remember to clean up manually.

---

## 6. File structure

```
project3/
├── server.js        # HTTP server + REST routing (Pillars 3 & 4)
├── db.js             # Schema, connection, seed data (Pillars 1 & 2)
├── public/
│   └── index.html    # Demo console: users, categories, task board
├── data/
│   └── app.db         # SQLite file (created on first run)
└── README.md
```

## 7. Try it with curl

```bash
# Create a user
curl -X POST localhost:3000/api/users \
  -H 'Content-Type: application/json' \
  -d '{"name":"Ada Lovelace","email":"ada@decodelabs.tech"}'

# Create a task for them
curl -X POST localhost:3000/api/tasks \
  -H 'Content-Type: application/json' \
  -d '{"user_id":1,"title":"Ship the schema","status":"in_progress"}'

# Flip its status (PATCH = partial update)
curl -X PATCH localhost:3000/api/tasks/1 \
  -H 'Content-Type: application/json' \
  -d '{"status":"done"}'

# Filter tasks
curl "localhost:3000/api/tasks?status=done"
```

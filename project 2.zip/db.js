// db.js
// -----------------------------------------------------------------------
// Project 3: Database Integration — DecodeLabs Task Manager
//
// This module owns the schema (Pillar 1: The Blueprint) and the
// connection (Pillar 2: The Bridge). It uses Node's built-in `node:sqlite`
// driver — a native driver, same category as `pg` for Postgres — so the
// project has zero external dependencies and runs anywhere Node runs.
//
// Schema relationships modeled here (see slide "Structuring Data Through
// Relational Geometry"):
//   users (1) ----< tasks        one-to-many
//   tasks (M) >---< categories   many-to-many, via task_categories
// -----------------------------------------------------------------------

const { DatabaseSync } = require('node:sqlite');
const path = require('path');
const fs = require('fs');

const DATA_DIR = path.join(__dirname, 'data');
if (!fs.existsSync(DATA_DIR)) fs.mkdirSync(DATA_DIR, { recursive: true });

const DB_PATH = path.join(DATA_DIR, 'app.db');
const db = new DatabaseSync(DB_PATH);

// Foreign keys are OFF by default in SQLite — must opt in per connection.
// Without this, ON DELETE CASCADE and FK constraints are silently ignored.
db.exec('PRAGMA foreign_keys = ON;');

// -----------------------------------------------------------------------
// Pillar 1: The Blueprint — schema with constraints enforced at the DB
// level (slide: "The Database is the Final Source of Truth"). We never
// trust the application layer alone to guarantee integrity.
// -----------------------------------------------------------------------
db.exec(`
  CREATE TABLE IF NOT EXISTS users (
    id         INTEGER PRIMARY KEY AUTOINCREMENT,
    name       TEXT NOT NULL,
    email      TEXT NOT NULL UNIQUE,
    created_at TEXT NOT NULL DEFAULT (datetime('now'))
  );

  CREATE TABLE IF NOT EXISTS categories (
    id   INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL UNIQUE
  );

  CREATE TABLE IF NOT EXISTS tasks (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id     INTEGER NOT NULL,
    title       TEXT NOT NULL,
    description TEXT,
    status      TEXT NOT NULL DEFAULT 'pending'
                  CHECK (status IN ('pending', 'in_progress', 'done')),
    due_date    TEXT,
    created_at  TEXT NOT NULL DEFAULT (datetime('now')),
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
  );

  -- Junction table resolving the many-to-many relationship between
  -- tasks and categories (slide: "Many-to-Many (M:M) ... Requires a
  -- junction table").
  CREATE TABLE IF NOT EXISTS task_categories (
    task_id     INTEGER NOT NULL,
    category_id INTEGER NOT NULL,
    PRIMARY KEY (task_id, category_id),
    FOREIGN KEY (task_id)     REFERENCES tasks(id)      ON DELETE CASCADE,
    FOREIGN KEY (category_id) REFERENCES categories(id) ON DELETE CASCADE
  );

  CREATE INDEX IF NOT EXISTS idx_tasks_user_id ON tasks(user_id);
  CREATE INDEX IF NOT EXISTS idx_tasks_status  ON tasks(status);
`);

// -----------------------------------------------------------------------
// Seed data — only runs once (guarded by checking if users table is empty)
// so restarting the server never duplicates rows.
// -----------------------------------------------------------------------
function seed() {
  const { count } = db.prepare('SELECT COUNT(*) AS count FROM users').get();
  if (count > 0) return;

  const insertUser = db.prepare('INSERT INTO users (name, email) VALUES (?, ?)');
  const insertCategory = db.prepare('INSERT INTO categories (name) VALUES (?)');
  const insertTask = db.prepare(`
    INSERT INTO tasks (user_id, title, description, status, due_date)
    VALUES (?, ?, ?, ?, ?)
  `);
  const linkTaskCategory = db.prepare(
    'INSERT INTO task_categories (task_id, category_id) VALUES (?, ?)'
  );

  const alice = insertUser.run('Alice Chen', 'alice@decodelabs.tech');
  const bilal = insertUser.run('Bilal Raza', 'bilal@decodelabs.tech');

  const work = insertCategory.run('Work');
  const urgent = insertCategory.run('Urgent');
  const learning = insertCategory.run('Learning');

  const t1 = insertTask.run(
    alice.lastInsertRowid, 'Design database schema',
    'Model users, tasks, and categories with proper keys.', 'in_progress', '2026-07-20'
  );
  const t2 = insertTask.run(
    alice.lastInsertRowid, 'Write CRUD endpoints',
    'Implement REST routes for all four operations.', 'pending', '2026-07-22'
  );
  const t3 = insertTask.run(
    bilal.lastInsertRowid, 'Review SQL injection defenses',
    'Confirm every query is parameterized.', 'pending', '2026-07-21'
  );

  linkTaskCategory.run(t1.lastInsertRowid, work.lastInsertRowid);
  linkTaskCategory.run(t1.lastInsertRowid, learning.lastInsertRowid);
  linkTaskCategory.run(t2.lastInsertRowid, work.lastInsertRowid);
  linkTaskCategory.run(t3.lastInsertRowid, urgent.lastInsertRowid);
}

seed();

module.exports = db;

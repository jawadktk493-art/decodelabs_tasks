// script.js
// -----------------------------------------------------------------------
// DecodeLabs — Project 1: Responsive Frontend Interface
// Pillar: "JavaScript — The Logic". Plain JS, no frameworks, no build step.
// Everything here is basic state management + DOM interactivity:
//   1. Mobile nav toggle
//   2. Theme toggle (light/dark)
//   3. Resource card rendering + live search/category filter
//   4. Progress checklist with a derived progress bar
//   5. Newsletter form (client-side validation feedback only)
//   6. Back-to-top button tied to scroll position
// -----------------------------------------------------------------------
(function () {
  'use strict';

  // -----------------------------------------------------------------
  // 1. Mobile navigation toggle
  // -----------------------------------------------------------------
  const navToggle = document.getElementById('nav-toggle');
  const navList = document.getElementById('nav-list').closest('.primary-nav');

  navToggle.addEventListener('click', () => {
    const isOpen = navList.classList.toggle('is-open');
    navToggle.setAttribute('aria-expanded', String(isOpen));
  });

  // Close the mobile menu after a nav link is clicked (small-screen only)
  navList.querySelectorAll('.nav-link').forEach((link) => {
    link.addEventListener('click', () => {
      if (window.matchMedia('(max-width: 767px)').matches) {
        navList.classList.remove('is-open');
        navToggle.setAttribute('aria-expanded', 'false');
      }
      navList.querySelectorAll('.nav-link').forEach((l) => l.classList.remove('is-active'));
      link.classList.add('is-active');
    });
  });

  // -----------------------------------------------------------------
  // 2. Theme toggle
  // -----------------------------------------------------------------
  const themeToggle = document.getElementById('theme-toggle');
  const themeIcon = themeToggle.querySelector('.theme-icon');

  function applyTheme(theme) {
    document.documentElement.setAttribute('data-theme', theme);
    themeToggle.setAttribute('aria-pressed', String(theme === 'dark'));
    themeIcon.textContent = theme === 'dark' ? '☀️' : '🌙';
  }

  // Respect the visitor's OS-level preference on first load.
  const prefersDark = window.matchMedia('(prefers-color-scheme: dark)').matches;
  applyTheme(prefersDark ? 'dark' : 'light');

  themeToggle.addEventListener('click', () => {
    const current = document.documentElement.getAttribute('data-theme');
    applyTheme(current === 'dark' ? 'light' : 'dark');
  });

  // -----------------------------------------------------------------
  // 3. Resource data + rendering + search/filter state
  // -----------------------------------------------------------------
  const RESOURCES = [
    { id: 1, category: 'frontend', tag: 'Frontend', title: 'Semantic HTML5 Landmarks', desc: 'Header, nav, main, article, footer — the right element for the right job.' },
    { id: 2, category: 'frontend', tag: 'Frontend', title: 'CSS Grid for Page Layout', desc: 'A strict 2D floor-plan for whole-page structure, from header to footer.' },
    { id: 3, category: 'frontend', tag: 'Frontend', title: 'Flexbox for Components', desc: 'One-dimensional alignment for nav bars, cards, and button rows.' },
    { id: 4, category: 'frontend', tag: 'Frontend', title: 'Fluid Type with clamp()', desc: 'Headlines that scale smoothly with the viewport instead of jumping.' },
    { id: 5, category: 'backend', tag: 'Backend', title: 'Database Schema Design', desc: 'Modeling one-to-many and many-to-many relationships with keys.' },
    { id: 6, category: 'backend', tag: 'Backend', title: 'RESTful CRUD Endpoints', desc: 'Mapping Create/Read/Update/Delete to POST/GET/PUT/DELETE.' },
    { id: 7, category: 'backend', tag: 'Backend', title: 'Parameterized Queries', desc: 'Defending against SQL injection by never concatenating raw input.' },
    { id: 8, category: 'devops', tag: 'DevOps', title: 'Mobile-First Breakpoints', desc: 'Start at one column, expand at 768px and 1024px with min-width queries.' },
    { id: 9, category: 'devops', tag: 'DevOps', title: 'Accessibility Auditing', desc: 'Checking landmarks, contrast, and keyboard focus before shipping.' },
  ];

  const grid = document.getElementById('card-grid');
  const searchInput = document.getElementById('search-input');
  const filterChips = document.querySelectorAll('.filter-chip');
  const resultsStatus = document.getElementById('results-status');

  // In-memory UI state — no persistence needed for a demo of the pattern.
  const state = { query: '', category: 'all' };

  function cardTemplate(item) {
    return `
      <article class="resource-card" data-category="${item.category}">
        <span class="card-tag">${item.tag}</span>
        <h3>${item.title}</h3>
        <p>${item.desc}</p>
        <a class="card-link" href="#resources">Read more →</a>
      </article>
    `;
  }

  function render() {
    const q = state.query.trim().toLowerCase();
    const filtered = RESOURCES.filter((item) => {
      const matchesCategory = state.category === 'all' || item.category === state.category;
      const matchesQuery = !q || item.title.toLowerCase().includes(q) || item.desc.toLowerCase().includes(q);
      return matchesCategory && matchesQuery;
    });

    grid.innerHTML = filtered.length
      ? filtered.map(cardTemplate).join('')
      : '<p class="no-results">No resources match your search. Try a different term or filter.</p>';

    resultsStatus.textContent = `Showing ${filtered.length} of ${RESOURCES.length} resources.`;
  }

  searchInput.addEventListener('input', (e) => {
    state.query = e.target.value;
    render();
  });

  filterChips.forEach((chip) => {
    chip.addEventListener('click', () => {
      filterChips.forEach((c) => c.classList.remove('is-active'));
      chip.classList.add('is-active');
      state.category = chip.dataset.filter;
      render();
    });
  });

  render(); // initial paint

  // -----------------------------------------------------------------
  // 4. Progress checklist
  // -----------------------------------------------------------------
  const checklistInputs = document.querySelectorAll('#checklist input[type="checkbox"]');
  const progressFill = document.getElementById('progress-fill');
  const progressBar = document.getElementById('progress-bar');
  const progressCount = document.getElementById('progress-count');
  const progressTotal = document.getElementById('progress-total');

  progressTotal.textContent = String(checklistInputs.length);

  function updateProgress() {
    const total = checklistInputs.length;
    const done = Array.from(checklistInputs).filter((cb) => cb.checked).length;
    const pct = Math.round((done / total) * 100);
    progressFill.style.width = pct + '%';
    progressBar.setAttribute('aria-valuenow', String(pct));
    progressCount.textContent = String(done);
  }

  checklistInputs.forEach((cb) => cb.addEventListener('change', updateProgress));
  updateProgress();

  // -----------------------------------------------------------------
  // 5. Newsletter form — client-side feedback only, no network call
  // -----------------------------------------------------------------
  const newsletterForm = document.getElementById('newsletter-form');
  const newsletterStatus = document.getElementById('newsletter-status');

  newsletterForm.addEventListener('submit', (e) => {
    e.preventDefault();
    const email = document.getElementById('newsletter-email').value.trim();
    if (!email) return;
    newsletterStatus.textContent = `You're on the list — we'll send updates to ${email}.`;
    newsletterForm.reset();
  });

  // -----------------------------------------------------------------
  // 6. Back-to-top button
  // -----------------------------------------------------------------
  const backToTop = document.getElementById('back-to-top');

  window.addEventListener('scroll', () => {
    backToTop.classList.toggle('is-visible', window.scrollY > 480);
  }, { passive: true });

  backToTop.addEventListener('click', () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  });
})();

# DecodeLabs — Project 1: Responsive Frontend Interface
### DecodeLabs Learning Hub — a mobile-first, framework-free interface

A working implementation of the training kit's brief: semantic HTML5,
CSS Grid + Flexbox, mobile-first breakpoints, fluid typography, and
JavaScript-driven interactivity — no frameworks, exactly per "The Mandate."

---

## 1. Run it

No build step, no dependencies. Just open `index.html` in a browser, or
serve the folder locally:

```bash
npx serve .
# or
python3 -m http.server 8000
```

## 2. How it maps to the three pillars

### Pillar 1 — Strategy & the blueprint
The page follows the wireframe from the deck exactly: `<header>` with nav,
a hero section, a main content grid paired with a side panel, and a
`<footer>`. It was structured mobile-first — single column first, then
expanded — rather than designed desktop-first and squeezed down.

### Pillar 2 — Visual design & 2025 aesthetics
- **Palette** (as specified): Mocha Mousse `#A5958F` (stability), Ethereal
  Blue `#A0D4E0` (trust), Moonlit Grey `#F2F0EA` (refinement).
- **Type pairing**: Inter for display/headings, Open Sans for body —
  **2 font families, 3 weights total** (Inter 700/600, Open Sans 400),
  matching the brief's constraint exactly.
- A dark theme is included (toggle in the header) using the same palette
  inverted, plus a check for the visitor's OS-level `prefers-color-scheme`.

### Pillar 3 — Implementation
- **Semantic HTML5**: `header`, `nav`, `main`, `section`, `article`,
  `aside`, `footer`, `address` — landmarks a screen reader (or an AI agent)
  can use as a table of contents, not a wall of `<div>`s.
- **CSS Grid** for macro layout — the content section is a single column
  on mobile and becomes a `2.2fr / 1fr` two-column grid (main content +
  side panel) at the 1024px desktop breakpoint.
- **Flexbox** for micro components — the header row, nav list, filter
  chips, and button groups.
- **Mobile-first media queries**, `min-width` only:
  - Tablet: `768px` (nav becomes an inline row, toolbar goes horizontal)
  - Desktop: `1024px` (two-column grid layout activates)
- **Fluid typography** via `clamp()` — headline and body sizes scale
  smoothly with the viewport instead of snapping at breakpoints.
- **JavaScript — state & interactivity**, all vanilla, no frameworks:
  1. Mobile nav toggle (`aria-expanded` kept in sync)
  2. Theme toggle (light/dark)
  3. Live search + category filter over a small resource dataset (re-renders
     the card grid and announces result counts via `aria-live`)
  4. A checklist that drives a derived progress bar
  5. A newsletter form with inline validation feedback (no network call)
  6. A scroll-aware "back to top" button

## 3. Accessibility notes
- A skip link jumps straight to `#main-content` for keyboard users.
- All interactive controls have visible focus rings (`:focus-visible`),
  proper `aria-*` state (`aria-expanded`, `aria-pressed`, `aria-live`,
  `role="progressbar"`), and accessible labels for icon-only buttons.
- `prefers-reduced-motion` is respected — animations and smooth scrolling
  are disabled for users who've asked for that at the OS level.
- Color contrast was checked against both the light and dark palettes.

## 4. File structure

```
project1/
├── index.html   # Semantic structure
├── style.css     # Mobile-first styles, Grid + Flexbox, design tokens
├── script.js     # Vanilla JS interactivity (no dependencies)
└── README.md
```
